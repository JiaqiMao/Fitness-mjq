package org.example.a.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.example.a.entity.Manager;

public interface maojiaqi {
    @Select("SELECT * FROM manager WHERE managerID = #{managerID} AND password = #{password}")
    Manager getManagerByNameAndPassword(@Param("managerID") String managerID, @Param("password") String password);


}