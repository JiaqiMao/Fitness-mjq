package org.example.a.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface managerRepository extends JpaRepository {
}
