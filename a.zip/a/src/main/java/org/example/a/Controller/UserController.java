package org.example.a.Controller;


import jakarta.annotation.Resource;
import org.example.a.entity.User;
import org.example.a.mapper.userMapper;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
    @Resource
    private userMapper userMapper;

    @PostMapping("/login")
    public User login(@RequestBody User user) {
        User dbUser = userMapper.getUserByNameAndPassword(user.getUsername(), user.getPassword());
            return dbUser;

    }
}


