package org.example.a.Controller;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import org.example.a.model.UserRequest;
import org.example.a.service.RegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RegisterController {

    private final RegisterService registerService;

    @Autowired
    public RegisterController(RegisterService registerService) {
        this.registerService = registerService;
    }

    @PostMapping("/register")
    public String register(@RequestBody UserRequest userRequest, HttpServletRequest request) {

        HttpSession session = request.getSession();
        if (!registerService.verifyCode(session, userRequest.getCode())) {
            return "验证码错误，请重新输入";
        }


        if (registerService.userExists(userRequest.getUsername())) {
            return "用户已存在，请直接登录";
        }

        registerService.registerUser(userRequest.getUsername(), userRequest.getPassword(), userRequest.getEmail());
        return "注册成功";
    }
}