package org.example.a.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.example.a.entity.User;
public interface userMapper {
    @Select("SELECT * FROM users WHERE username = #{username} AND password = #{password}")
    User getUserByNameAndPassword(@Param("username") String username, @Param("password") String password);

}
