package org.example.a.service;
import jakarta.servlet.http.HttpSession;
import org.example.a.entity.User;
import org.example.a.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class RegisterService {

    private final UserRepository userRepository;

    @Autowired
    public RegisterService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public boolean userExists(String username) {
        return userRepository.existsByUsername(username);
    }

    public void registerUser(String username, String password, String email) {
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setEmail(email);
        userRepository.save(user);
    }
    public boolean verifyCode(HttpSession session, String code){
    Integer sessionCode = (Integer) session.getAttribute("code");
        if (sessionCode == null) {
            // 如果 session 中没有验证码，返回 false
            return false;
        }

        // 与请求中的验证码进行比较
        return sessionCode.toString().equals(code);
    }
}
